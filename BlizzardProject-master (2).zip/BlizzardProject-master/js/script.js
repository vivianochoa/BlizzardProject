/* Write your code here */
var web = angular.module ("web,[]")
web.controller("",)